const fs = require("fs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const http = require("http");
const express = require("express");

const PORT = 3000;
const USER = { "신입생": "newdimigo", "admin": crypto.randomBytes(64).toString('hex') };
const FLAG = fs.readFileSync("./flag.txt");
const pubKey = fs.readFileSync("./rsa/public.pem");
const privKey = fs.readFileSync("./rsa/private.pem");


const app = express();

app.set("view engine", "ejs");
app.use(express.json())
app.use(require("cookie-parser")())
app.use(express.urlencoded({ extended: false }));
app.use("/static", express.static('static'))

app.get("/", (req, res) => {
    if (req.cookies.session) {
        try {
            const user = jwt.verify(req.cookies.session, pubKey, { algorithms: ['RS256', 'HS256'] });
            if (user.username === "admin")
                return res.render("index", { uid: FLAG });
            else
                return res.render("index", { uid: user.username });
        }catch (e) {
            return res.render("index", { uid: false });
        }
    }else {
        return res.render('index', { uid: false });
    }
});

app.get("/login", (req, res) => {
    return res.render('login', { msg: false });
});

app.post("/login", (req, res) => {
    const body = req.body;
    if (!(body.id && body.pw))
        return res.render("login", { msg: "Error" });

    let login = false;
    Object.keys(USER).forEach((k, i) => {
        if (k === body.id && USER[k] === body.pw && !login) {
            login = true
            const payload = { 'username': k };
            const jwtToken = jwt.sign(payload, privKey, { expiresIn: '1h', algorithm: 'RS256' });
            res.cookie('session', jwtToken, { maxAge: 900000, httpOnly: true });
            return res.redirect("/");
        }else if (i === Object.keys(USER).length-1 && !login) {
            return res.render("login", { msg: "아이디와 비밀번호가 일치하지 않습니다." });
        }
    });
});

app.get("/logout", (req, res) => {
    res.clearCookie("session")
    res.redirect("/");
});

const server = http.createServer(app);
server.listen(PORT, () => {
    console.log(`Express server is listening on port ${PORT}`)
});