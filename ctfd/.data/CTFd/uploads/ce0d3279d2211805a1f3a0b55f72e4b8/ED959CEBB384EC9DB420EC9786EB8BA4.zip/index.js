const fs = require("fs");
const jwt = require("veryokjsonwebtoken");
const crypto = require("crypto");

const http = require("http");
const express = require("express");

const PORT = 3000;
const USER = { "신입생": "newdimigo", "admin": crypto.randomBytes(64).toString('hex') };
const FLAG = fs.readFileSync("./flag.txt");
const SECRET = crypto.randomBytes(64).toString('hex');


const app = express();

app.set("view engine", "ejs");
app.use(express.json())
app.use(require("cookie-parser")())
app.use(express.urlencoded({ extended: false }));
app.use("/static", express.static('static'))

app.get("/", (req, res) => {
    if (req.cookies.session) {
        try {
            const user = jwt.verify(req.cookies.session, SECRET);
            if (user.username === "admin")
                res.render("index", { uid: FLAG });
            else
                res.render("index", { uid: user.username });
        }catch (e) {
            res.render("index", { uid: false });
            console.log(e)
        }
    }else {
        res.render('index', { uid: false });
    }
});

app.get("/login", (req, res) => {
    res.render('login', { msg: false });
});

app.post("/login", (req, res) => {
    const body = req.body;
    if (!(body.id && body.pw))
        res.render("login", { msg: "Error" });

    Object.keys(USER).forEach((k) => {
        if (k === body.id && USER[k] === body.pw) {
            const payload = { 'username': k };
            const jwtToken = jwt.sign(payload, SECRET, { expiresIn: '1h', algorithm: 'HS256' });
            res.cookie('session', jwtToken, { maxAge: 900000, httpOnly: true });
            res.redirect("/");
        }else {
            res.render("login", { msg: "아이디와 비밀번호가 일치하지 않습니다." });
        }
    });
});

app.get("/logout", (req, res) => {
    res.clearCookie("session")
    res.redirect("/");
});

const server = http.createServer(app);
server.listen(PORT, () => {
    console.log(`Express server is listening on port ${PORT}`)
});