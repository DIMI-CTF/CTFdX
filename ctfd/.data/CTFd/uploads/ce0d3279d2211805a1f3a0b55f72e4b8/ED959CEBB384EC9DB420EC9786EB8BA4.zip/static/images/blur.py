import cv2
import os

for i in os.listdir():
    if i.endswith(".png") and not i.endswith("_blur.png"):
      img = cv2.imread(i)
      img = cv2.GaussianBlur(img, (35, 35), 0)
      cv2.imwrite(i.replace(".png", "_blur.png"), img)